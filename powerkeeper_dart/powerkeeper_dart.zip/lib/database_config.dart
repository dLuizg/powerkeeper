// lib/database_config.dart

class DatabaseConfig {
  static const String host = 'localhost'; // ou 'localhost'
  static const int port = 3306;
  static const String user = 'root'; // <-- MUDE AQUI (ex: 'root')
  static const String password = '296q'; // <-- MUDE AQUI
  static const String db = 'powerkeeper'; // O nome do schema que você criou
}
