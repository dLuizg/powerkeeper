// lib/sync_service.dart

import '/database_service.dart';
import 'firebase_service.dart';
import 'models.dart';

class SyncService {
  final FirebaseService _firebaseService;
  final DatabaseService _databaseService;

  SyncService(this._firebaseService, this._databaseService);

  // ------------------------- FUNÇÃO PRINCIPAL DE SINCRONIZAÇÃO -------------------------

  /// Sincroniza APENAS os dados de Consumos Diários do Firebase para o MySQL.
  Future<void> syncConsumosDiariosOnly() async {
    print(
        '🔄 Iniciando sincronização APENAS de Consumos Diários (Firebase → MySQL)...');

    // 1. Conectar ao Firebase
    await _firebaseService.connect();

    // 2. Buscar Consumos Diários do Firebase
    print('Buscando Consumos Diários (consumos_diarios) não sincronizados...');
    final List<ConsumoDiario> consumos =
        await _firebaseService.getConsumosDiariosNaoSincronizados();

    if (consumos.isEmpty) {
      print('✅ Nenhum Consumo Diário novo para sincronizar.');
      return;
    }

    print(
        '📊 Encontrados ${consumos.length} Consumo(s) Diário(s) para sincronizar.');

    int successCount = 0;
    int errorCount = 0;

    // 3. Garantir a conexão com o MySQL
    // O método _getValidConnection() no DatabaseService já cuida disso.

    // 4. Inserir no MySQL e marcar no Firebase
    for (final consumo in consumos) {
      try {
        // Insere o consumo no MySQL
        final result = await _databaseService.insertConsumoDiario(consumo);

        if (result == "sucesso") {
          // 5. Marca como sincronizado no Firebase se a inserção for bem-sucedida
          await _firebaseService
              .marcarConsumoComoSincronizado(consumo.firebaseKey);
          successCount++;
        } else if (result.startsWith("aviso:")) {
          // Item já existe (evita marcar como erro)
          print(
              '⚠️ Aviso: Consumo Diário ${consumo.firebaseKey} já existe no MySQL. Pulando marcação.');
          successCount++; // Ainda conta como "processado"
        } else {
          // Outros erros (FK, etc.)
          print(
              '❌ Erro ao sincronizar Consumo Diário ${consumo.firebaseKey}: $result');
          errorCount++;
        }
      } catch (e) {
        print(
            '❌ Erro inesperado ao sincronizar Consumo Diário ${consumo.firebaseKey}: $e');
        errorCount++;
      }
    }

    print('\n📈 Resumo da Sincronização de Consumos Diários:');
    print('    ✅ Sincronizados com sucesso: $successCount');
    print('    ❌ Erros: $errorCount');
    print('    📦 Total processado: ${successCount + errorCount}');
  }
}
