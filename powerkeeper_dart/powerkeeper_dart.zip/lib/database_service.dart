// lib/database_service.dart

import 'package:mysql1/mysql1.dart';
import 'models.dart'; // Assumindo que models.dart existe e contém Leitura e ConsumoDiario
import 'dart:io';

class DatabaseService {
  MySqlConnection? _conn;
  bool _conectado = false;

  bool get conectado => _conectado;

  // --- CONFIGURE AQUI SEU BANCO MYSQL ---
  final _settings = ConnectionSettings(
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '296q', // Sua senha
    db: 'powerkeeper',
  );
  // ----------------------------------------

  Future<void> connect() async {
    await _conn?.close().catchError((_) {});

    try {
      _conn = await MySqlConnection.connect(_settings);
      _conectado = true;
      print("Conectado ao MySQL (DatabaseService) com sucesso!");
    } catch (e) {
      print("❌ ERRO FATAL ao conectar ao MySQL:");
      print("Verifique as credenciais e o status do servidor.");
      print(e);
      _conectado = false;
      exit(1);
    }
  }

  /// Verifica se a conexão está viva e reconecta se necessário.
  Future<MySqlConnection> _getValidConnection() async {
    if (_conn == null || !_conectado) {
      print('🔌 Conexão MySQL não iniciada. Conectando...');
      await connect();
    }
    try {
      await _conn!.query('SELECT 1');
    } catch (e) {
      print('⚠️ Conexão MySQL perdida. Reconectando...');
      await connect();
    }
    return _conn!;
  }

  Future<void> close() async {
    await _conn?.close();
    _conectado = false;
    print("Conexão MySQL fechada.");
  }

  // --- FUNÇÕES DE SINCRONIZAÇÃO (Firebase -> MySQL) ---

  Future<String> insertLeitura(Leitura leitura) async {
    final conn = await _getValidConnection();
    final DateTime timeStampUtc = leitura.timeStamp.toUtc();
    try {
      await conn.transaction((txn) async {
        final sql = '''
        INSERT INTO leitura 
          (timeStamp, corrente, tensao, dispositivo_idDispositivo)
        VALUES (?, ?, ?, ?);
        ''';
        final params = [
          timeStampUtc,
          leitura.corrente,
          leitura.tensao,
          leitura.dispositivoId,
        ];
        await txn.query(sql, params);
      });
      return "sucesso";
    } on MySqlException catch (e) {
      if (e.errorNumber == 1452) {
        return "Erro FK: O dispositivoId ${leitura.dispositivoId} não existe na tabela 'dispositivo'.";
      }
      if (e.errorNumber == 1062) {
        return "aviso: Leitura já existe";
      }
      return "Erro MySQL: ${e.message}";
    } catch (e) {
      return "Erro inesperado: $e";
    }
  }

  Future<String> insertConsumoDiario(ConsumoDiario consumo) async {
    final conn = await _getValidConnection();
    final DateTime timeStampUtc = consumo.timeStamp.toUtc();

    try {
      await conn.transaction((txn) async {
        final sql = '''
        INSERT INTO consumodiario 
          (timeStamp, consumoKWh, dispositivo_idDispositivo) 
        VALUES (?, ?, ?);
        ''';
        final params = [
          timeStampUtc,
          consumo.consumoKwh,
          consumo.dispositivoId,
        ];
        await txn.query(sql, params);
      });

      return "sucesso";
    } on MySqlException catch (e) {
      if (e.errorNumber == 1452) {
        return "Erro FK: O dispositivoId ${consumo.dispositivoId} não existe na tabela 'dispositivo'.";
      }
      if (e.errorNumber == 1062) {
        return "aviso: Consumo já existe";
      }
      return "Erro MySQL: ${e.message}";
    } catch (e) {
      return "Erro inesperado: $e";
    }
  }

  // --- FUNÇÕES DE LEITURA E GERENCIAMENTO PARA O CLI (CORRIGIDAS) ---

  // Empresa
  Future<void> addEmpresa(String nome, String cnpj) async {
    final conn = await _getValidConnection();
    await conn
        .query('INSERT INTO empresa (nome, cnpj) VALUES (?, ?)', [nome, cnpj]);
  }

  Future<List<String>> getEmpresas() async {
    final conn = await _getValidConnection();
    final results = await conn.query('SELECT * FROM empresa');
    return results
        .map((row) => "ID: ${row[0]}, Nome: ${row[1]}, CNPJ: ${row[2]}")
        .toList();
  }

  Future<void> deleteEmpresa(int id) async {
    final conn = await _getValidConnection();
    await conn.query('DELETE FROM empresa WHERE idEmpresa = ?', [id]);
  }

  // Funcionário (AGORA ACESSANDO POR NOME DE CAMPO)
  Future<String> addFuncionario(
      String nome, String email, String senha, int idEmpresa) async {
    try {
      final conn = await _getValidConnection();
      await conn.query(
          'INSERT INTO funcionario (nome, email, senhaLogin, empresa_idEmpresa) VALUES (?, ?, ?, ?)',
          [nome, email, senha, idEmpresa]);
      return "Funcionário adicionado com sucesso.";
    } on MySqlException catch (e) {
      if (e.errorNumber == 1452)
        return "Erro: Empresa com ID $idEmpresa não existe.";
      return "Erro MySQL: ${e.message}";
    }
  }

  Future<List<String>> getFuncionarios() async {
    final conn = await _getValidConnection(); // Await duplicado removido
    // Seleciona colunas explicitamente
    final results = await conn.query(
        'SELECT f.idFuncionario, f.nome, f.email, f.senhaLogin, e.nome as nomeEmpresa FROM funcionario f JOIN empresa e ON f.empresa_idEmpresa = e.idEmpresa');

    return results
        .map((row) =>
            // CORREÇÃO FINAL: Acessar campos por nome, mais robusto contra erros de índice
            "ID: ${row.fields['idFuncionario']}, Nome: ${row.fields['nome']}, Email: ${row.fields['email']}, Empresa: ${row.fields['nomeEmpresa']}")
        .toList();
  }

  Future<void> deleteFuncionario(int id) async {
    final conn = await _getValidConnection();
    await conn.query('DELETE FROM funcionario WHERE idFuncionario = ?', [id]);
  }

  // Local (ÍNDICE CORRIGIDO PARA [4])
  Future<String> addLocal(String nome, String referencia, int idEmpresa) async {
    try {
      final conn = await _getValidConnection();
      await conn.query(
          'INSERT INTO local (nome, referencia, empresa_idEmpresa) VALUES (?, ?, ?)',
          [nome, referencia, idEmpresa]);
      return "Local adicionado com sucesso.";
    } on MySqlException catch (e) {
      if (e.errorNumber == 1452)
        return "Erro: Empresa com ID $idEmpresa não existe.";
      return "Erro MySQL: ${e.message}";
    }
  }

  Future<List<String>> getLocais() async {
    final conn = await _getValidConnection();

    final results = await conn.query('''
    SELECT 
      l.idLocal,
      l.nome,
      l.referencia,
      l.empresa_idEmpresa,
      e.nome AS nomeEmpresa
    FROM local l
    JOIN empresa e ON l.empresa_idEmpresa = e.idEmpresa
  ''');

    return results.map((row) {
      final f = row.fields;
      return "ID: ${f['idLocal']}, Nome: ${f['nome']}, Ref: ${f['referencia']}, Empresa: ${f['nomeEmpresa']}";
    }).toList();
  }

  Future<void> deleteLocal(int id) async {
    final conn = await _getValidConnection();
    await conn.query('DELETE FROM local WHERE idLocal = ?', [id]);
  }

  // Dispositivo (ÍNDICE CORRIGIDO PARA [4])
  Future<String> addDispositivo(
      String modelo, String status, int idLocal) async {
    try {
      final conn = await _getValidConnection();
      await conn.query(
          'INSERT INTO dispositivo (modelo, status, local_idLocal) VALUES (?, ?, ?)',
          [modelo, status, idLocal]);
      return "Dispositivo adicionado com sucesso.";
    } on MySqlException catch (e) {
      if (e.errorNumber == 1452)
        return "Erro: Local com ID $idLocal não existe.";
      return "Erro MySQL: ${e.message}";
    }
  }

  Future<List<String>> getDispositivos() async {
    final conn = await _getValidConnection();

    final results = await conn.query('''
    SELECT 
      d.idDispositivo,
      d.modelo,
      d.status,
      d.local_idLocal,
      l.nome AS nomeLocal
    FROM dispositivo d
    JOIN local l ON d.local_idLocal = l.idLocal
  ''');

    return results.map((row) {
      final f = row.fields;
      return "ID: ${f['idDispositivo']}, Modelo: ${f['modelo']}, Status: ${f['status']}, Local: ${f['nomeLocal']}";
    }).toList();
  }

  Future<void> deleteDispositivo(int id) async {
    final conn = await _getValidConnection();
    await conn.query('DELETE FROM dispositivo WHERE idDispositivo = ?', [id]);
  }

  // --- FUNÇÕES DE TABELA CLI (Para Listar) ---

  Future<List<Map<String, dynamic>>> getEmpresasForTable() async {
    final conn = await _getValidConnection();
    final results =
        await conn.query('SELECT idEmpresa, nome, cnpj FROM empresa');
    return results.map((row) => row.fields).toList();
  }

  Future<List<Map<String, dynamic>>> getFuncionariosForTable() async {
    final conn = await _getValidConnection();
    final results = await conn.query(
        'SELECT f.idFuncionario, f.nome, f.email, e.nome as empresa FROM funcionario f JOIN empresa e ON f.empresa_idEmpresa = e.idEmpresa');
    return results.map((row) => row.fields).toList();
  }

  Future<List<Map<String, dynamic>>> getLocaisForTable() async {
    final conn = await _getValidConnection();

    final results = await conn.query('''
    SELECT 
      l.idLocal,
      l.nome,
      l.referencia,
      e.nome as empresa
    FROM local l
    JOIN empresa e ON l.empresa_idEmpresa = e.idEmpresa
  ''');

    return results.map((row) => row.fields).toList();
  }

  Future<List<Map<String, dynamic>>> getDispositivosForTable() async {
    final conn = await _getValidConnection();

    final results = await conn.query('''
    SELECT 
      d.idDispositivo,
      d.modelo,
      d.status,
      l.nome AS local
    FROM dispositivo d
    JOIN local l ON d.local_idLocal = l.idLocal
  ''');

    return results.map((row) => row.fields).toList();
  }

  Future<List<Map<String, dynamic>>> getLeiturasForTable(int limite) async {
    final conn = await _getValidConnection();
    final results = await conn.query('''
        SELECT 
          l.idLeitura, 
          DATE_FORMAT(CONVERT_TZ(l.timeStamp, '+00:00', 'SYSTEM'), '%Y-%m-%d %H:%i:%s') as timeStamp, 
          l.corrente, 
          l.tensao, 
          d.modelo as dispositivo
        FROM leitura l
        LEFT JOIN dispositivo d ON l.dispositivo_idDispositivo = d.idDispositivo
        ORDER BY l.idLeitura DESC 
        LIMIT ?
      ''', [limite]);
    return results.map((row) {
      var fields = row.fields;
      fields['corrente'] =
          double.tryParse(fields['corrente'].toString()) ?? 0.0;
      fields['tensao'] = double.tryParse(fields['tensao'].toString()) ?? 0.0;
      return fields;
    }).toList();
  }
}
